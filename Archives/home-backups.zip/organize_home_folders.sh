#!/bin/bash
# Comprehensive Home Folder Organization Script
# Analyzes and organizes all contents recursively

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Dry run mode (set to false to actually move files)
DRY_RUN=true

log() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

move_file() {
    local src="$1"
    local dst="$2"
    
    if [ "$DRY_RUN" = true ]; then
        echo "  [DRY RUN] Would move: $src → $dst"
    else
        mkdir -p "$(dirname "$dst")"
        mv "$src" "$dst" && log "Moved: $src → $dst"
    fi
}

# ============================================================================
# DOWNLOADS ORGANIZATION
# ============================================================================
organize_downloads() {
    log "Organizing Downloads folder..."
    
    cd ~/Downloads || exit 1
    
    # Create structure
    mkdir -p Archives/{DMG,Zips,Extracted}
    mkdir -p Images/{SVG,PNG,Other}
    mkdir -p Scripts
    mkdir -p Misc
    
    # Move DMG folder
    if [ -d "DMG" ]; then
        move_file "DMG" "Archives/DMG"
    fi
    
    # Move Zips folder
    if [ -d "Zips" ]; then
        move_file "Zips" "Archives/Zips"
    fi
    
    # Organize Pictures folder
    if [ -d "Pictures" ]; then
        if [ -d "Pictures/svg" ]; then
            find Pictures/svg -type f -name "*.svg" -exec sh -c 'move_file "$1" "Images/SVG/$(basename "$1")"' _ {} \;
        fi
        if [ -d "Pictures/png" ]; then
            find Pictures/png -type f -name "*.png" -exec sh -c 'move_file "$1" "Images/PNG/$(basename "$1")"' _ {} \;
        fi
        rmdir Pictures/svg Pictures/png 2>/dev/null || true
        rmdir Pictures 2>/dev/null || true
    fi
    
    # Organize ∗new folder (SVG icons)
    if [ -d "∗new" ]; then
        if [ -d "∗new/svg" ]; then
            find "∗new/svg" -type f -name "*.svg" -exec sh -c 'move_file "$1" "Images/SVG/$(basename "$1")"' _ {} \;
        fi
        if [ -d "∗new/png" ]; then
            find "∗new/png" -type f -name "*.png" -exec sh -c 'move_file "$1" "Images/PNG/$(basename "$1")"' _ {} \;
        fi
        rmdir "∗new/svg" "∗new/png" 2>/dev/null || true
        rmdir "∗new" 2>/dev/null || true
    fi
    
    # Move loose script files
    find . -maxdepth 1 -type f -name "*.applescript" -exec sh -c 'move_file "$1" "Scripts/$(basename "$1")"' _ {} \;
    find . -maxdepth 1 -type f -name "*.sh" -exec sh -c 'move_file "$1" "Scripts/$(basename "$1")"' _ {} \;
    find . -maxdepth 1 -type f -name "*.py" -exec sh -c 'move_file "$1" "Scripts/$(basename "$1")"' _ {} \;
    
    # Move extracted archives from Zips to Extracted
    if [ -d "Archives/Zips" ]; then
        find Archives/Zips -maxdepth 1 -type d ! -name "Zips" ! -name "." -exec sh -c 'move_file "$1" "Archives/Extracted/$(basename "$1")"' _ {} \;
    fi
}

# ============================================================================
# DOCUMENTS ORGANIZATION
# ============================================================================
organize_documents() {
    log "Organizing Documents folder..."
    
    cd ~/Documents || exit 1
    
    # Create structure
    mkdir -p Apps/{Hookmark,Supercharge,Textsoap9cleaner}
    mkdir -p Development/{Terminal,Huggingface}
    mkdir -p Reference/{Dotfiles,Music-Library-Docs}
    mkdir -p Backups
    
    # Move app-specific folders
    [ -d "Hookmark" ] && move_file "Hookmark" "Apps/Hookmark"
    [ -d "Supercharge" ] && move_file "Supercharge" "Apps/Supercharge"
    [ -d "Textsoap9cleaner" ] && move_file "Textsoap9cleaner" "Apps/Textsoap9cleaner"
    
    # Move development folders
    [ -d "Terminal" ] && move_file "Terminal" "Development/Terminal"
    [ -d "Huggingface" ] && move_file "Huggingface" "Development/Huggingface"
    
    # Move reference materials
    [ -d "Dotfile Inspiration" ] && move_file "Dotfile Inspiration" "Reference/Dotfiles"
    [ -d "Backups" ] && move_file "Backups" "Backups"  # Keep in place, just ensure it exists
}

# ============================================================================
# DESKTOP ORGANIZATION
# ============================================================================
organize_desktop() {
    log "Organizing Desktop folder..."
    
    cd ~/Desktop || exit 1
    
    # Move Deemix (music albums) to Music
    if [ -d "Deemix" ]; then
        mkdir -p ~/Music/Downloads
        move_file "Deemix" ~/Music/Downloads/Deemix
    fi
    
    # Move Icons (git repo) to Projects
    if [ -d "Icons" ]; then
        mkdir -p ~/Projects
        move_file "Icons" ~/Projects/Icons
    fi
    
    # Move Music-Library-Docs to Documents/Reference
    if [ -d "Music-Library-Docs" ]; then
        mkdir -p ~/Documents/Reference
        move_file "Music-Library-Docs" ~/Documents/Reference/Music-Library-Docs
    fi
    
    # Move loose script files
    find . -maxdepth 1 -type f -name "*.py" -exec sh -c 'move_file "$1" ~/Scripts/Dev/$(basename "$1")' _ {} \;
    find . -maxdepth 1 -type f -name "*.sh" -exec sh -c 'move_file "$1" ~/Scripts/Utilities/$(basename "$1")' _ {} \;
}

# ============================================================================
# MAIN
# ============================================================================
main() {
    log "Starting home folder organization..."
    log "Mode: $([ "$DRY_RUN" = true ] && echo "DRY RUN" || echo "LIVE")"
    echo ""
    
    organize_downloads
    echo ""
    organize_documents
    echo ""
    organize_desktop
    echo ""
    
    log "Organization complete!"
    
    if [ "$DRY_RUN" = true ]; then
        warn "This was a DRY RUN. Set DRY_RUN=false to actually move files."
    fi
}

main "$@"
