# Home Folder Contents Organization Plan

**Generated:** 2026-01-08

## Current State Analysis

### 📁 Documents/ (28M total)

**Folders:**
- `Backups/` (18M) - Backup files
- `Dotfile Inspiration/` (177M) - Large collection of dotfile examples
- `Hookmark/` (3M) - Hookmark app data
- `Huggingface/` (12K) - Hugging Face related
- `Supercharge/` (7.5M) - Supercharge app data
- `Terminal/` (68K) - Terminal settings
- `Textsoap9cleaner/` (4K) - TextSoap cleaner

**Loose files:** 0 ✅

### 📥 Downloads/ (643M total)

**Folders:**
- `DMG/` (136M) - DMG installer files
- `Zips/` (337M) - ZIP archives
- `∗new/` (2.8M) - Unclear purpose (weird name)
- `Pictures/` (1.8M) - Downloaded images

**Loose files:**
- `ghostty alfred.applescript` (12K) - Should move to Scripts

### 🖥️ Desktop/ (3.8M total)

**Folders:**
- `Deemix/` (0B - contains music album folders: Chaos Relic, Pendulum, Ritual Fúnebre)
- `Icons/` (0B - git repo with icon folders: macos, linux, color, misc, new)
- `Music-Library-Docs/` (28K)

**Loose files:**
- `eksternal-stats.py` (16K) - Python script, should move to Scripts or Projects

### 🖼️ Pictures/ (1.3GB total)

**Folders:**
- `dp/` - Dance pictures?
- `Music/` - Music-related images
- `Photo Booth Library/` - macOS Photo Booth
- `Photos Library.photoslibrary/` - macOS Photos app
- `Pixelmator Pro Sidecar Files/` - Pixelmator metadata
- `uPic/` - Image uploader tool
- `Wallpapers/` - Wallpaper collection

## Organization Strategy

### Phase 1: Organize Downloads (Priority: High)

**Downloads is cluttered with 473M of archives:**

1. **Create organized structure:**
   ```
   ~/Downloads/
   ├── Archives/          (NEW - consolidate DMG & Zips)
   │   ├── DMG/          (move from ~/Downloads/DMG)
   │   └── Zips/         (move from ~/Downloads/Zips)
   ├── Images/            (NEW - downloaded pictures)
   │   └── Pictures/     (move from ~/Downloads/Pictures)
   └── Misc/              (NEW - temporary/unclear items)
       └── ∗new/         (move from ~/Downloads/∗new)
   ```

2. **Move loose files:**
   - `ghostty alfred.applescript` → `~/Scripts/Apps/` or `~/Scripts/Dev/`

### Phase 2: Organize Documents (Priority: Medium)

**Documents has good structure but could be better organized:**

1. **Create categories:**
   ```
   ~/Documents/
   ├── Apps/              (NEW - app-specific data)
   │   ├── Hookmark/     (move from ~/Documents/Hookmark)
   │   ├── Supercharge/  (move from ~/Documents/Supercharge)
   │   └── Textsoap9cleaner/ (move from ~/Documents/Textsoap9cleaner)
   ├── Development/        (NEW - dev-related)
   │   ├── Huggingface/  (move from ~/Documents/Huggingface)
   │   └── Terminal/     (move from ~/Documents/Terminal)
   ├── Reference/         (NEW - reference materials)
   │   └── Dotfile Inspiration/ (move from ~/Documents/Dotfile Inspiration)
   └── Backups/            (keep as-is)
   ```

### Phase 3: Clean Desktop (Priority: High)

**Desktop should be minimal:**

1. **Move folders:**
   - `Deemix/` → `~/Music/Deemix/` (music album downloads) OR `~/Downloads/Misc/Deemix/`
   - `Icons/` → `~/Projects/Icons/` (git repo - belongs with projects) OR keep in Desktop if actively working on it
   - `Music-Library-Docs/` → `~/Documents/Reference/Music-Library-Docs/`

2. **Move loose files:**
   - `eksternal-stats.py` → `~/Scripts/Dev/` or `~/Projects/Git/` (if part of a project)

### Phase 4: Organize Pictures (Priority: Low)

**Pictures structure is mostly fine, but could be cleaner:**

1. **Keep as-is** (macOS Photos and Photo Booth are system-managed)
2. **Consider consolidating:**
   - `dp/` → Could move to `~/Pictures/Personal/` if personal photos
   - `Music/` → Already organized
   - `Wallpapers/` → Keep as-is (well organized)

## Detailed Action Plan

### Step 1: Downloads Cleanup (10 minutes)

```bash
# Create structure
mkdir -p ~/Downloads/Archives/{DMG,Zips}
mkdir -p ~/Downloads/Images
mkdir -p ~/Downloads/Misc

# Move folders
mv ~/Downloads/DMG ~/Downloads/Archives/
mv ~/Downloads/Zips ~/Downloads/Archives/
mv ~/Downloads/Pictures ~/Downloads/Images/
mv ~/Downloads/∗new ~/Downloads/Misc/

# Move loose file
mv ~/Downloads/ghostty\ alfred.applescript ~/Scripts/Apps/
```

### Step 2: Documents Organization (5 minutes)

```bash
# Create structure
mkdir -p ~/Documents/Apps
mkdir -p ~/Documents/Development
mkdir -p ~/Documents/Reference

# Move folders
mv ~/Documents/Hookmark ~/Documents/Apps/
mv ~/Documents/Supercharge ~/Documents/Apps/
mv ~/Documents/Textsoap9cleaner ~/Documents/Apps/
mv ~/Documents/Huggingface ~/Documents/Development/
mv ~/Documents/Terminal ~/Documents/Development/
mv ~/Documents/Dotfile\ Inspiration ~/Documents/Reference/
```

### Step 3: Desktop Cleanup (5 minutes)

```bash
# Move folders
# Deemix: music albums - move to Music or Downloads/Misc
mv ~/Desktop/Deemix ~/Music/Deemix
# OR if temporary: mv ~/Desktop/Deemix ~/Downloads/Misc/Deemix

# Icons: git repo - move to Projects
mv ~/Desktop/Icons ~/Projects/Icons

# Music-Library-Docs: reference material
mv ~/Desktop/Music-Library-Docs ~/Documents/Reference/

# Move loose file
mv ~/Desktop/eksternal-stats.py ~/Scripts/Dev/
```

## Final Structure

### Downloads/
```
Downloads/
├── Archives/
│   ├── DMG/          (136M)
│   └── Zips/          (337M)
├── Images/
│   └── Pictures/     (1.8M)
└── Misc/
    └── ∗new/         (2.8M)
```

### Documents/
```
Documents/
├── Apps/
│   ├── Hookmark/     (3M)
│   ├── Supercharge/  (7.5M)
│   └── Textsoap9cleaner/ (4K)
├── Development/
│   ├── Huggingface/  (12K)
│   └── Terminal/     (68K)
├── Reference/
│   ├── Dotfile Inspiration/ (177M)
│   └── Music-Library-Docs/ (28K)
└── Backups/          (18M)
```

### Desktop/
```
Desktop/
└── (clean - only shortcuts/current work)
```

## Benefits

1. **Downloads** - Easy to find archives vs images vs misc
2. **Documents** - Clear categories (Apps, Development, Reference)
3. **Desktop** - Clean workspace
4. **Consistent** - Same organizational philosophy as Scripts

## Implementation

Would you like me to:
1. **Create the folder structure** automatically?
2. **Move files** to their new locations?
3. **Generate a script** you can review before running?
4. **Check what's in the empty-looking folders** first (Deemix, Icons)?
