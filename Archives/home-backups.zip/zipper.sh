#!/bin/bash
# Automator Quick Action: Compress selected files/folders
# Interactive format + archive name dialogs

# Ensure input exists
if [ $# -eq 0 ]; then
  osascript -e 'display alert "No files selected" message "Please select files or folders in Finder first."'
  exit 1
fi

FILES=("$@")
BASE_DIR="$(dirname "${FILES[0]}")"

# -----------------------
# Choose format
# -----------------------
FORMAT=$(osascript <<EOF
choose from list {"zip","7z","tar.gz","xz","zst","rar","z","dmg"} \
with title "Archive Format" \
with prompt "Choose compression format:"
EOF
)

[ "$FORMAT" = "false" ] && exit 0

# -----------------------
# Ask for archive name
# -----------------------
ARCHIVE_NAME=$(osascript <<EOF
display dialog "Enter archive name:" default answer "$(basename "$BASE_DIR")" \
with title "Archive Name"
text returned of result
EOF
)

[ -z "$ARCHIVE_NAME" ] && exit 0

ARCHIVE_PATH="$BASE_DIR/$ARCHIVE_NAME.$FORMAT"

# -----------------------
# Temp file list (for Keka / safety)
# -----------------------
TMP_LIST="/tmp/archive_filelist.txt"
printf "%s\n" "${FILES[@]}" > "$TMP_LIST"

# -----------------------
# Compress
# -----------------------
case "$FORMAT" in
  zip)
    cd "$BASE_DIR" || exit 1
    zip -r "$ARCHIVE_PATH" $(basename -a "${FILES[@]}")
    ;;

  7z)
    /Applications/Keka.app/Contents/Resources/keka7z \
      a -t7z "$ARCHIVE_PATH" @"$TMP_LIST"
    ;;

  tar.gz)
    tar -czf "$ARCHIVE_PATH" "${FILES[@]}"
    ;;

  xz)
    tar -cf - "${FILES[@]}" | xz -9 > "$ARCHIVE_PATH"
    ;;

  zst)
    tar -cf - "${FILES[@]}" | zstd -19 -o "$ARCHIVE_PATH"
    ;;

  z)
    tar -cf - "${FILES[@]}" | compress > "$ARCHIVE_PATH"
    ;;

  rar)
    if command -v rar >/dev/null; then
      rar a "$ARCHIVE_PATH" "${FILES[@]}"
    else
      osascript -e 'display alert "RAR not installed" message "Install via Homebrew: brew install rar"'
      exit 1
    fi
    ;;

  dmg)
    hdiutil create "$ARCHIVE_PATH" -srcfolder "${FILES[0]}" -format UDZO
    ;;
esac

rm -f "$TMP_LIST"

# -----------------------
# Success notification
# -----------------------
osascript -e "display notification \"Created $ARCHIVE_NAME.$FORMAT\" with title \"Archive Complete\""
