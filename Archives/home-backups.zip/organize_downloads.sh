#!/bin/bash
# Organize Downloads folder by logical purpose
# Groups items by what they ARE and what they're FOR, not just file types

set -euo pipefail

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Dry run mode - set to false to actually move files
DRY_RUN=true

log() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

move_item() {
    local src="$1"
    local dst="$2"
    
    if [ ! -e "$src" ]; then
        return 0
    fi
    
    if [ "$DRY_RUN" = true ]; then
        echo "  [DRY RUN] Would move: $(basename "$src") → $dst"
    else
        mkdir -p "$(dirname "$dst")"
        if mv "$src" "$dst" 2>/dev/null; then
            log "Moved: $(basename "$src") → $dst"
        else
            warn "Failed to move: $src"
        fi
    fi
}

organize_downloads() {
    log "Organizing Downloads folder..."
    cd ~/Downloads || exit 1
    
    # ========================================================================
    # 1. TERMINAL CONFIGURATIONS
    # ========================================================================
    log "Organizing Terminal configurations..."
    mkdir -p Terminal/WezTerm/{configs,color-schemes,builds}
    mkdir -p Terminal/Ghostty
    
    # WezTerm configs
    [ -d "Zips/wezterm-config-master" ] && move_item "Zips/wezterm-config-master" "Terminal/WezTerm/configs/wezterm-config-master"
    [ -d "Zips/wezterm-config-master-1" ] && move_item "Zips/wezterm-config-master-1" "Terminal/WezTerm/configs/wezterm-config-master-1"
    
    # WezTerm color schemes
    [ -d "Zips/yutkat dotfiles main .config-wezterm" ] && move_item "Zips/yutkat dotfiles main .config-wezterm" "Terminal/WezTerm/color-schemes/yutkat-wezterm"
    [ -d "Zips/yutkat dotfiles main -1.config-wezterm" ] && move_item "Zips/yutkat dotfiles main -1.config-wezterm" "Terminal/WezTerm/color-schemes/yutkat-wezterm-1"
    [ -d "Zips/deathrashed color-schemes master wezterm" ] && move_item "Zips/deathrashed color-schemes master wezterm" "Terminal/WezTerm/color-schemes/deathrashed-wezterm"
    
    # WezTerm app builds
    [ -d "Zips/WezTerm-macos-20240203-110809-5046fc22" ] && move_item "Zips/WezTerm-macos-20240203-110809-5046fc22" "Terminal/WezTerm/builds/WezTerm-macos-20240203-110809-5046fc22"
    [ -d "Zips/WezTerm-macos-20240203-110809-5046fc22-1" ] && move_item "Zips/WezTerm-macos-20240203-110809-5046fc22-1" "Terminal/WezTerm/builds/WezTerm-macos-20240203-110809-5046fc22-1"
    
    # Ghostty scripts
    [ -f "ghostty alfred.applescript" ] && move_item "ghostty alfred.applescript" "Terminal/Ghostty/ghostty-alfred.applescript"
    
    # ========================================================================
    # 2. HAMMERSPOON
    # ========================================================================
    log "Organizing Hammerspoon..."
    mkdir -p Hammerspoon/{app,spoons}
    
    [ -d "Zips/Hammerspoon-1.1.0" ] && move_item "Zips/Hammerspoon-1.1.0" "Hammerspoon/app/Hammerspoon-1.1.0"
    [ -d "Zips/Hammerspoon.app" ] && move_item "Zips/Hammerspoon.app" "Hammerspoon/app/Hammerspoon.app"
    [ -d "Zips/SpoonInstall.spoon" ] && move_item "Zips/SpoonInstall.spoon" "Hammerspoon/spoons/SpoonInstall.spoon"
    [ -d "Zips/SpoonInstall_spoon" ] && move_item "Zips/SpoonInstall_spoon" "Hammerspoon/spoons/SpoonInstall_spoon"
    
    # ========================================================================
    # 3. SCRIPTS
    # ========================================================================
    log "Organizing Scripts..."
    mkdir -p Scripts/ScriptKit
    
    [ -d "Zips/scriptkit-scripts-main" ] && move_item "Zips/scriptkit-scripts-main" "Scripts/ScriptKit/scriptkit-scripts-main"
    [ -d "Zips/scriptkit-scripts-main-1" ] && move_item "Zips/scriptkit-scripts-main-1" "Scripts/ScriptKit/scriptkit-scripts-main-1"
    
    # ========================================================================
    # 4. DEVELOPMENT SDKs
    # ========================================================================
    log "Organizing Development SDKs..."
    mkdir -p Development/SDKs
    
    [ -d "Zips/angelscript_2.38.0" ] && move_item "Zips/angelscript_2.38.0" "Development/SDKs/angelscript_2.38.0"
    
    # ========================================================================
    # 5. MEDIA COLLECTIONS (organized by purpose)
    # ========================================================================
    log "Organizing Media collections..."
    mkdir -p Media/{Icons/{SVG,PNG},Collections,Cars,Music}
    
    # Image collections
    [ -d "Zips/Images" ] && move_item "Zips/Images" "Media/Collections/Images"
    [ -d "Zips/Images-1" ] && move_item "Zips/Images-1" "Media/Collections/Images-1"
    [ -d "Zips/Images-2" ] && move_item "Zips/Images-2" "Media/Collections/Images-2"
    [ -d "Zips/Images-3" ] && move_item "Zips/Images-3" "Media/Collections/Images-3"
    [ -d "Zips/Images 2" ] && move_item "Zips/Images 2" "Media/Collections/Images-2-alt"
    
    # Car images
    [ -d "Zips/cars1" ] && move_item "Zips/cars1" "Media/Cars/cars1"
    [ -d "Zips/cars1-1" ] && move_item "Zips/cars1-1" "Media/Cars/cars1-1"
    
    # Music images
    [ -d "Zips/music" ] && move_item "Zips/music" "Media/Music/music"
    
    # Icons - organize SVG and PNG files
    if [ -d "Pictures" ]; then
        if [ -d "Pictures/svg" ]; then
            find Pictures/svg -maxdepth 1 -type f -name "*.svg" 2>/dev/null | while read -r file; do
                move_item "$file" "Media/Icons/SVG/$(basename "$file")"
            done
        fi
        if [ -d "Pictures/png" ]; then
            find Pictures/png -maxdepth 1 -type f -name "*.png" 2>/dev/null | while read -r file; do
                move_item "$file" "Media/Icons/PNG/$(basename "$file")"
            done
        fi
    fi
    
    if [ -d "∗new" ]; then
        if [ -d "∗new/svg" ]; then
            find "∗new/svg" -maxdepth 1 -type f -name "*.svg" 2>/dev/null | while read -r file; do
                move_item "$file" "Media/Icons/SVG/$(basename "$file")"
            done
        fi
        if [ -d "∗new/png" ]; then
            find "∗new/png" -maxdepth 1 -type f -name "*.png" 2>/dev/null | while read -r file; do
                move_item "$file" "Media/Icons/PNG/$(basename "$file")"
            done
        fi
    fi
    
    # ========================================================================
    # 6. PRESETS
    # ========================================================================
    log "Organizing Presets..."
    mkdir -p Presets
    
    [ -d "Zips/preset" ] && move_item "Zips/preset" "Presets/preset"
    
    # ========================================================================
    # 7. CLEANUP EMPTY FOLDERS
    # ========================================================================
    log "Cleaning up empty folders..."
    if [ "$DRY_RUN" = false ]; then
        rmdir Pictures/svg Pictures/png 2>/dev/null || true
        rmdir Pictures 2>/dev/null || true
        rmdir "∗new/svg" "∗new/png" 2>/dev/null || true
        rmdir "∗new" 2>/dev/null || true
        
        # Check if Zips folder is empty (except .DS_Store)
        if [ -d "Zips" ] && [ -z "$(find Zips -mindepth 1 -maxdepth 1 ! -name '.DS_Store' -print -quit)" ]; then
            rmdir Zips 2>/dev/null || true
        fi
    else
        echo "  [DRY RUN] Would clean up empty folders"
    fi
    
    # ========================================================================
    # 8. DMG FILES NOTE
    # ========================================================================
    if [ -d "DMG" ] && [ "$(find DMG -type f -name "*.dmg" 2>/dev/null | wc -l)" -gt 0 ]; then
        warn "DMG files found in DMG/ folder"
        warn "  Note: You clean DMG names and move them to /Volumes/Apfspace/Disk Images"
        warn "  DMG folder left as-is for your manual processing"
    fi
}

main() {
    log "Starting Downloads organization..."
    log "Mode: $([ "$DRY_RUN" = true ] && echo "DRY RUN (no files will be moved)" || echo "LIVE (files will be moved)")"
    echo ""
    
    organize_downloads
    
    echo ""
    log "Downloads organization complete!"
    
    if [ "$DRY_RUN" = true ]; then
        echo ""
        warn "This was a DRY RUN. To actually move files, run:"
        warn "  DRY_RUN=false ~/organize_downloads.sh"
    fi
}

main "$@"
