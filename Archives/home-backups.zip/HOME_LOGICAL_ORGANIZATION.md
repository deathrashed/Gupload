# Home Folder Logical Organization Plan

**Generated:** 2026-01-08

## Organization Philosophy

- **Organize by PURPOSE and FUNCTION**, not just file types
- **Clean names** where needed
- **Group related items** logically
- **Respect existing workflows** (like DMG → `/Volumes/Apfspace/Disk Images`)

## Current State Analysis

### 📥 Downloads/ (643M)

**By Purpose:**

**Terminal/Shell Configurations:**
- `wezterm-config-master` / `wezterm-config-master-1` - WezTerm configs
- `WezTerm-macos-*` - WezTerm app builds
- `yutkat dotfiles main .config-wezterm` / `-1.config-wezterm` - WezTerm color schemes
- `deathrashed color-schemes master wezterm` - Your color schemes

**Hammerspoon Configuration:**
- `Hammerspoon-1.1.0` - Hammerspoon app
- `Hammerspoon.app` - Hammerspoon app bundle
- `SpoonInstall.spoon` / `SpoonInstall_spoon` - Hammerspoon spoons

**Scripts & Automation:**
- `scriptkit-scripts-main` / `scriptkit-scripts-main-1` - ScriptKit scripts
- `ghostty alfred.applescript` - Alfred workflow for Ghostty terminal

**Development Libraries/SDKs:**
- `angelscript_2.38.0` - AngelScript SDK

**Media Collections:**
- `Images` / `Images-1` / `Images-2` / `Images-3` / `Images 2` - Image collections
- `cars1` / `cars1-1` - Car images
- `music` - Music-related images
- `Pictures/svg` / `Pictures/png` - Icon images
- `∗new/svg` / `∗new/png` - New icon collection

**Presets/Configs:**
- `preset` - Unknown presets

**Archives (DMG):**
- `DMG/` - Should go to `/Volumes/Apfspace/Disk Images` (per your workflow)

### 📄 Documents/

**App Configurations:**
- `Hookmark/` - Hookmark app templates and files
- `Supercharge/` - Supercharge app data
- `Textsoap9cleaner/` - TextSoap cleaner configs

**Development:**
- `Terminal/` - Terminal settings/profiles
- `Huggingface/` - Hugging Face related

**Reference Materials:**
- `Dotfile Inspiration/` - Dotfile examples/reference (177M - huge!)
- `Music-Library-Docs/` - Documentation about music library structure

**Backups:**
- `Backups/` - Backup files (kmmacros, zip)

### 🖥️ Desktop/

**Active Projects:**
- `Icons/` - Git repo (iconica) - icon collection project
- `Deemix/` - Music album downloads (Chaos Relic, Pendulum, Ritual Fúnebre)
- `Music-Library-Docs/` - Documentation project
- `eksternal-stats.py` - Music collection statistics script

## Recommended Logical Organization

### 📥 Downloads/ Structure

```
Downloads/
├── Terminal/                    (Terminal configs & apps)
│   ├── WezTerm/
│   │   ├── configs/            (wezterm-config-master, etc.)
│   │   ├── color-schemes/       (yutkat dotfiles, deathrashed schemes)
│   │   └── builds/              (WezTerm-macos-* app builds)
│   └── Ghostty/
│       └── ghostty-alfred.applescript
│
├── Hammerspoon/                 (Hammerspoon configs)
│   ├── app/                     (Hammerspoon-1.1.0, Hammerspoon.app)
│   └── spoons/                  (SpoonInstall.spoon, etc.)
│
├── Scripts/                     (Script collections)
│   └── ScriptKit/               (scriptkit-scripts-main)
│
├── Development/                 (SDKs, libraries)
│   └── SDKs/
│       └── AngelScript/         (angelscript_2.38.0)
│
├── Media/                       (Image/media collections)
│   ├── Icons/                   (SVG/PNG icons from Pictures, ∗new)
│   ├── Collections/              (Images, Images-1, etc.)
│   ├── Cars/                    (cars1, cars1-1)
│   └── Music/                   (music folder)
│
└── Presets/                     (preset folder)
```

**Note:** DMG files should go to `/Volumes/Apfspace/Disk Images` (your existing workflow)

### 📄 Documents/ Structure

```
Documents/
├── Apps/                        (App-specific data)
│   ├── Hookmark/
│   ├── Supercharge/
│   └── TextSoap/
│
├── Development/                 (Dev tools & configs)
│   ├── Terminal/
│   └── Huggingface/
│
├── Reference/                   (Reference materials)
│   ├── Dotfiles/                (Dotfile Inspiration - rename & organize)
│   └── Music-Library/           (Music-Library-Docs)
│
└── Backups/                     (Keep as-is)
```

### 🖥️ Desktop/ Structure

**Desktop should be clean - move active projects:**

```
Desktop/ → Move to appropriate locations:

Icons/ → ~/Projects/Icons/        (Git repo - active project)
Deemix/ → ~/Music/Downloads/      (Music downloads)
Music-Library-Docs/ → ~/Documents/Reference/Music-Library/
eksternal-stats.py → ~/Scripts/Dev/ or ~/Projects/Git/ (if part of project)
```

## Detailed Organization Plan

### Phase 1: Downloads Organization

#### 1.1 Terminal Configurations
```bash
mkdir -p ~/Downloads/Terminal/{WezTerm/{configs,color-schemes,builds},Ghostty}
mv ~/Downloads/Zips/wezterm-config-master* ~/Downloads/Terminal/WezTerm/configs/
mv ~/Downloads/Zips/yutkat* ~/Downloads/Terminal/WezTerm/color-schemes/
mv ~/Downloads/Zips/deathrashed* ~/Downloads/Terminal/WezTerm/color-schemes/
mv ~/Downloads/Zips/WezTerm-macos-* ~/Downloads/Terminal/WezTerm/builds/
mv ~/Downloads/ghostty\ alfred.applescript ~/Downloads/Terminal/Ghostty/
```

#### 1.2 Hammerspoon
```bash
mkdir -p ~/Downloads/Hammerspoon/{app,spoons}
mv ~/Downloads/Zips/Hammerspoon* ~/Downloads/Hammerspoon/app/
mv ~/Downloads/Zips/SpoonInstall* ~/Downloads/Hammerspoon/spoons/
```

#### 1.3 Scripts
```bash
mkdir -p ~/Downloads/Scripts/ScriptKit
mv ~/Downloads/Zips/scriptkit-scripts-main* ~/Downloads/Scripts/ScriptKit/
```

#### 1.4 Development SDKs
```bash
mkdir -p ~/Downloads/Development/SDKs
mv ~/Downloads/Zips/angelscript_2.38.0 ~/Downloads/Development/SDKs/
```

#### 1.5 Media Collections
```bash
mkdir -p ~/Downloads/Media/{Icons/{SVG,PNG},Collections,Cars,Music}
# Consolidate all Images folders
mv ~/Downloads/Zips/Images* ~/Downloads/Media/Collections/
mv ~/Downloads/Zips/cars* ~/Downloads/Media/Cars/
mv ~/Downloads/Zips/music ~/Downloads/Media/Music/
# Organize icon files
mv ~/Downloads/Pictures/svg/*.svg ~/Downloads/Media/Icons/SVG/ 2>/dev/null || true
mv ~/Downloads/Pictures/png/*.png ~/Downloads/Media/Icons/PNG/ 2>/dev/null || true
mv ~/Downloads/∗new/svg/*.svg ~/Downloads/Media/Icons/SVG/ 2>/dev/null || true
mv ~/Downloads/∗new/png/*.png ~/Downloads/Media/Icons/PNG/ 2>/dev/null || true
```

#### 1.6 Presets
```bash
mkdir -p ~/Downloads/Presets
mv ~/Downloads/Zips/preset ~/Downloads/Presets/
```

#### 1.7 DMG Files
```bash
# Move DMG files to your existing location
# (You handle this manually or via your existing workflow)
# mv ~/Downloads/DMG/*.dmg /Volumes/Apfspace/Disk\ Images/
```

### Phase 2: Documents Organization

```bash
mkdir -p ~/Documents/{Apps/{Hookmark,Supercharge,TextSoap},Development/{Terminal,Huggingface},Reference/{Dotfiles,Music-Library}}

mv ~/Documents/Hookmark ~/Documents/Apps/
mv ~/Documents/Supercharge ~/Documents/Apps/
mv ~/Documents/Textsoap9cleaner ~/Documents/Apps/TextSoap
mv ~/Documents/Terminal ~/Documents/Development/
mv ~/Documents/Huggingface ~/Documents/Development/
mv ~/Documents/Dotfile\ Inspiration ~/Documents/Reference/Dotfiles
mv ~/Desktop/Music-Library-Docs ~/Documents/Reference/Music-Library/
```

### Phase 3: Desktop Cleanup

```bash
mkdir -p ~/Projects ~/Music/Downloads ~/Scripts/Dev

mv ~/Desktop/Icons ~/Projects/
mv ~/Desktop/Deemix ~/Music/Downloads/
mv ~/Desktop/eksternal-stats.py ~/Scripts/Dev/
```

### Phase 4: Clean Up Empty Folders

```bash
# Remove empty Zips folder after moving everything
rmdir ~/Downloads/Zips 2>/dev/null || true
rmdir ~/Downloads/Pictures 2>/dev/null || true
rmdir ~/Downloads/∗new 2>/dev/null || true
```

## Final Structure

### Downloads/
```
Downloads/
├── Terminal/
│   ├── WezTerm/
│   │   ├── configs/
│   │   ├── color-schemes/
│   │   └── builds/
│   └── Ghostty/
├── Hammerspoon/
│   ├── app/
│   └── spoons/
├── Scripts/
│   └── ScriptKit/
├── Development/
│   └── SDKs/
│       └── AngelScript/
├── Media/
│   ├── Icons/
│   │   ├── SVG/
│   │   └── PNG/
│   ├── Collections/
│   ├── Cars/
│   └── Music/
└── Presets/
```

### Documents/
```
Documents/
├── Apps/
│   ├── Hookmark/
│   ├── Supercharge/
│   └── TextSoap/
├── Development/
│   ├── Terminal/
│   └── Huggingface/
├── Reference/
│   ├── Dotfiles/
│   └── Music-Library/
└── Backups/
```

## Implementation Options

1. **Generate a script** that does all this organization
2. **Do it step-by-step** with your approval
3. **Create the folder structure first**, then move files
4. **Handle DMG files** - integrate with your `/Volumes/Apfspace/Disk Images` workflow

## Notes

- **DMG files**: Keep your existing workflow of cleaning names and moving to `/Volumes/Apfspace/Disk Images`
- **Icons project**: Active git repo, belongs in Projects
- **Deemix**: Music downloads, belongs in Music
- **Color schemes**: Grouped with terminal configs (logical grouping)
- **Media**: Organized by purpose (Icons, Collections, Cars, Music) not just file type

Would you like me to create the organization script, or do you want to review and modify this plan first?
