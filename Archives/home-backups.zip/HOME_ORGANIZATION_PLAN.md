# Home Folder Organization Plan

**Generated:** 2026-01-08

## Current State Analysis

### Top-Level Items in Home Folder

**Standard macOS Folders (Keep as-is):**
- Desktop, Documents, Downloads, Library, Movies, Music, Pictures, Public, Applications

**Project/Development Folders:**
- `Git/` - Development projects (3.2GB)
- `Scripts/` - Already organized perfectly ✅
- `Keyboard Maestro Macros/` - ❌ Already removed/cleaned up
- `Scripts.bak/` - ❌ Already removed/cleaned up

**Config/Symlink Folders:**
- `dotfiles/` - Dotfile management
- `iCloud` (symlink)
- `Obsidian` (symlink)
- `pCloud` (symlink)
- `pCloud Drive/` - Cloud storage
- `Support` (symlink)

**Loose Files (Need Organization):**
- `brew` - Empty file (0B) - likely can delete
- `firebase-debug.log` - Debug log (8KB) - should move to temp/logs
- `HOME_ORGANIZATION_PLAN.md` - This plan file (4.8KB) - can move to Documents or delete after implementation
- `Icon` - Empty file (0B) - likely can delete
- `reaper.png` - Image file (260KB) - should move to Pictures
- `zipper.sh` - Compression utility script (2.1K) - should move to `~/Scripts/Utilities/`

## Recommended Organization Structure

### Phase 1: Create Organized Structure

Create a `~/Projects/` folder to consolidate development work:

```
~/Projects/
└── Git/          (move from ~/Git - 3.2GB)
```

**Note:** `Keyboard Maestro Macros/` and `Scripts.bak/` have already been cleaned up ✅

**Simplified structure** - No need for extra nesting if Git is the main project folder.

### Phase 2: Organize Loose Files

**Create `~/Temp/` for temporary files:**
- Move `firebase-debug.log` → `~/Temp/Logs/`

**Move media files:**
- Move `reaper.png` → `~/Pictures/` (or create `~/Pictures/Misc/`)

**Move scripts:**
- Move `zipper.sh` → `~/Scripts/Utilities/` (compression utility - confirmed Utilities folder exists)

**Clean up empty/useless files:**
- Delete `brew` (empty file)
- Delete `Icon` (empty file)

### Phase 3: Create Supporting Folders

```
~/
├── Projects/          (NEW - all development work)
├── Temp/              (NEW - temporary files, logs)
│   └── Logs/
└── Archive/           (NEW - old backups, unused items)
```

## Detailed Action Plan

### Step 1: Quick Cleanup (5 minutes)
1. Delete empty files: `brew`, `Icon`
2. Move `firebase-debug.log` → `~/Temp/Logs/`
3. Move `reaper.png` → `~/Pictures/`

### Step 2: Organize Projects (2 minutes)
1. Create `~/Projects/` folder
2. Move `~/Git/` → `~/Projects/Git/` (3.2GB - may take a moment)
3. ✅ `Keyboard Maestro Macros/` - Already cleaned up
4. ✅ `Scripts.bak/` - Already cleaned up

### Step 3: Move Scripts (5 minutes)
1. Review `zipper.sh` - determine category
2. Move to appropriate `~/Scripts/` subfolder

### Step 4: Create Symlinks (Optional)
If you want to keep shortcuts in home:
```bash
ln -s ~/Projects/Git ~/Git
```

**Note:** Existing symlinks are valid:
- `iCloud` → iCloud Drive
- `Obsidian` → Obsidian vault
- `pCloud` → pCloud Drive
- `Support` → Application Support

## Final Structure

```
~/
├── Desktop/              (macOS standard)
├── Documents/            (macOS standard)
├── Downloads/            (macOS standard)
├── Pictures/             (macOS standard)
├── Movies/               (macOS standard)
├── Music/                (macOS standard)
├── Public/               (macOS standard)
├── Library/              (macOS standard)
├── Applications/         (Note: Not in home, in /Applications)
│
├── Projects/             (NEW - All development work)
│   └── Git/              (3.2GB)
│
├── Scripts/              (Already perfect!)
│   ├── Apps/
│   ├── Dev/
│   ├── Languages/
│   ├── Media/
│   ├── Productivity/
│   ├── Riley/
│   ├── System/
│   ├── Text/
│   ├── Utilities/
│   └── Web/
│
├── Temp/                 (NEW - Temporary files)
│   └── Logs/
│
├── dotfiles/             (Config management)
├── pCloud Drive/         (Cloud storage)
│
└── Symlinks:
    ├── iCloud → ...
    ├── Obsidian → ...
    ├── pCloud → ...
    └── Support → ...
```

## Benefits

1. **Cleaner home folder** - Only essential items at top level
2. **Logical grouping** - All projects in one place
3. **Easy navigation** - Clear structure
4. **Consistent with Scripts** - Same organizational philosophy
5. **Room to grow** - Easy to add new projects/categories

## Implementation Script

Would you like me to:
1. **Create the folder structure** automatically?
2. **Move files** to their new locations?
3. **Create symlinks** to maintain shortcuts?
4. **Generate a script** you can review before running?

## Notes

- Keep all dotfiles (`.config`, `.cursor`, etc.) in home - they're expected there
- Standard macOS folders stay in place
- Symlinks are valid and can stay as-is
- `zipper.sh` is a compression utility (zip/7z/tar.gz/etc.) - perfect for Scripts/Utilities
- `HOME_ORGANIZATION_PLAN.md` can be moved to Documents or deleted after implementation
